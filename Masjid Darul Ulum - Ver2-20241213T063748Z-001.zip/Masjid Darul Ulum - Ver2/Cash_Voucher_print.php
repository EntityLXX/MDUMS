
<?php
require ('fpdf/fpdf.php');
require ('config.php');
?>